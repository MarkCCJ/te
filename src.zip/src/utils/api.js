import axios from 'axios'
// import { now } from 'core-js/core/date';

let base = 'http://localhost:8080';
// let base = '';
export const postRequest = (url, params) => {
  sessionStorage.setItem("logStatus", true)
  return axios({
    method: 'post',
    url: `${base}${url}`,
    data: params,
    transformRequest: [function (data) {
      let ret = JSON.stringify(data);
      return ret
    }],
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
  });
}
export const uploadFileRequest = (url, params) => {
  return axios({
    method: 'post',
    url: `${base}${url}`,
    data: params,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
}
export const putRequest = (url, params) => {
  return axios({
    method: 'put',
    url: `${base}${url}`,
    data: params,
    transformRequest: [function (data) {
      let ret = ''
      for (let it in data) {
        ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
      }
      return ret
    }],
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });
}
export const deleteRequest = (url) => {
  return axios({
    method: 'delete',
    url: `${base}${url}`
  });
}
export const getRequest = (url) => {
  return axios({
    method: 'get',
    url: `${base}${url}`,
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  });
}

// Add a request interceptor
axios.interceptors.request.use(function (config) {
  var nowDate = new Date();
  var startTime = " "+nowDate.getHours()+":"+nowDate.getMinutes()+":"+nowDate.getSeconds()+"."+nowDate.getMilliseconds();
  console.log(nowDate.toISOString().substring(0, 10) + startTime +" SPAN Client-AP [Success] Request " + JSON.stringify(config));
  let logData = nowDate.toISOString().substring(0, 10) + startTime +" SPAN Client-AP [Success] Request " + JSON.stringify(config);
  
  if(sessionStorage.getItem("logStatus") == "false"){
    sessionStorage.removeItem("logStatus")
  }else{
    if(sessionStorage.getItem("logResponse") == "false"){
      console.log();
    }else{
    axios.post('http://localhost:9528/fround/api/logger', {
      logData,
    });
    sessionStorage.setItem("logStatus", false)
    }
  }
  return config;
}, function (error) {
  var nowDate = new Date();
  var startTime = " "+nowDate.getHours()+":"+nowDate.getMinutes()+":"+nowDate.getSeconds()+"."+nowDate.getMilliseconds();
  console.log(nowDate.toISOString().substring(0, 10) + startTime +" SPAN Client-AP [Fail] Request " + JSON.stringify(error));

  let logData = nowDate.toISOString().substring(0, 10) + startTime +" SPAN Client-AP [Success] Request " + JSON.stringify(error);


  if(sessionStorage.getItem("logStatus") == "false"){
    sessionStorage.removeItem("logStatus")
  }else{
    if(sessionStorage.getItem("logResponse") == "false"){
      console.log();
    }else{
      axios.post('http://localhost:9528/fround/api/logger', {
        logData,
      });
      sessionStorage.setItem("logStatus", false)
    }
    
}
  
  return Promise.reject(error);
});

// Add a response interceptor
axios.interceptors.response.use(function (response) {
  var nowDate = new Date();
  var endTime = " "+nowDate.getHours()+":"+nowDate.getMinutes()+":"+nowDate.getSeconds()+"."+nowDate.getMilliseconds();
  console.log(nowDate.toISOString().substring(0, 10) + endTime +" SPAN Client-AP [Success] Response " + JSON.stringify(response));



  let logData = nowDate.toISOString().substring(0, 10) + endTime +" SPAN Client-AP [Success] Response " + JSON.stringify(response)
  if(sessionStorage.getItem("logResponse") == "false"){
    sessionStorage.removeItem("logResponse")
  }else{
    axios.post('http://localhost:9528/fround/api/logger', {
      logData,
    });
    sessionStorage.setItem("logResponse", false)
}



  return response;
}, function (error) {
  var nowDate = new Date();
  var endTime = " "+nowDate.getHours()+":"+nowDate.getMinutes()+":"+nowDate.getSeconds()+"."+nowDate.getMilliseconds();
  console.log(nowDate.toISOString().substring(0, 10) + endTime +" SPAN Client-AP [Fail] Response " + JSON.stringify(error));



  let logData = nowDate.toISOString().substring(0, 10) + endTime +" SPAN Client-AP [Success] Response " + JSON.stringify(error)
  if(sessionStorage.getItem("logResponse") == "false"){
    sessionStorage.removeItem("logResponse")
  }else{
    axios.post('http://localhost:9528/fround/api/logger', {
      logData,
    });
    sessionStorage.setItem("logResponse", false)
}



  return Promise.reject(error);
});



